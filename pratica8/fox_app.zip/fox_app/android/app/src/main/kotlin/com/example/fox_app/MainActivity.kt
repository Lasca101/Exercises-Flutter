package com.example.fox_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
